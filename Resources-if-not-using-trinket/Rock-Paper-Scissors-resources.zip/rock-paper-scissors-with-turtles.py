from turtle import *
from random import randint
from time import sleep

#############################################
# VARIABLES
#############################################

screen = Screen()
screen.setup(450,400)
screen.bgcolor('lightcyan')

screen.register_shape('left_paper.gif')

#############################################
# FUNCTIONS
#############################################

#############################################
# MAIN CODE
#############################################

# In some Python editors the turtle window closes as soon as it has
# opened. If your editor does this then uncomment the following line
# and make sure it is always the last line in your code.

# done()

