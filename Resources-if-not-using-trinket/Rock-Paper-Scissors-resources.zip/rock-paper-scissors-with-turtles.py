from turtle import *
from random import randint
from time import sleep

#############################################
# VARIABLES
#############################################

screen = Screen()
screen.setup(450,400)
screen.bgcolor('lightcyan')

screen.register_shape('left_paper.gif')

#############################################
# FUNCTIONS
#############################################

#############################################
# MAIN CODE
#############################################

